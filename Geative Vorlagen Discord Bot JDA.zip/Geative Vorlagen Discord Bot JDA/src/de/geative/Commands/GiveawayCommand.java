package de.geative.Commands;

import de.geative.Management.ServerCommand;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;

import java.awt.*;
import java.util.Arrays;
import java.util.List;

public class GiveawayCommand implements ServerCommand {
    @Override
    public void performCommand(Member m, TextChannel channel, Message message) {
        List<String> args = Arrays.asList(message.getContentDisplay().split(" "));

        if (!m.hasPermission(Permission.ADMINISTRATOR)) {
            EmbedBuilder builder = new EmbedBuilder();
            builder.setColor(Color.RED);
            builder.setTitle("Giveaway \uD83C\uDF89");
            builder.setDescription("Du hast dafür keine Rechte.");

            channel.sendMessage(builder.getDescriptionBuilder());
        }
        final Member selfMember = m.getGuild().getSelfMember();
        if (!selfMember.hasPermission(Permission.MESSAGE_ADD_REACTION, Permission.MESSAGE_WRITE, Permission.MESSAGE_MANAGE )) {
            EmbedBuilder builder = new EmbedBuilder();
            builder.setColor(Color.RED);
            builder.setTitle("Giveaway \uD83C\uDF89");
            builder.setDescription("ich habe dafür keine Rechte.");

            channel.sendMessage((CharSequence) builder.build());
        }

        if (args.size() > 1) {
            channel.sendMessage("Missing Arguments").queue();
            return;
        }

        EmbedBuilder builder = new EmbedBuilder();
        builder.setDescription("");

    }
}
