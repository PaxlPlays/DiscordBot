package de.geative.Commands;

import de.geative.Management.ServerCommand;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;

import java.awt.*;
import java.time.OffsetDateTime;

public class HelpCommand implements ServerCommand {
    @Override
    public void performCommand(Member m, TextChannel channel, Message message) {

        EmbedBuilder builder = new EmbedBuilder();
        builder.setColor(Color.CYAN);
        builder.setTimestamp(OffsetDateTime.now());
        builder.setTitle("Hilfe");
        builder.addField("\uD83C\uDF9A Einstellungen", " ", false);
        builder.addField("\uD83C\uDFB5 Musik", " ", false);
        builder.addField("\uD83C\uDF9B Commands", " ", false);
        builder.addField("\uD83D\uDDC3 Profil", " ", false);
        builder.addField("\uD83D\uDCE1 Informationen", " ", false);
        builder.addField("\uD83D\uDCE8 Kontakt", " ", false);
        channel.sendMessage(builder.build()).queue(message2 -> {
            message2.addReaction("\uD83C\uDF9A").queue();
            message2.addReaction("\uD83C\uDFB5").queue();
            message2.addReaction("\uD83C\uDF9B").queue();
            message2.addReaction("\uD83D\uDDC3").queue();
            message2.addReaction("\uD83D\uDCE1").queue();
            message2.addReaction("\uD83D\uDCE8").queue();
        });

    }
}
