package de.geative.Commands;

import de.geative.Geative;
import de.geative.Management.ServerCommand;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;

import java.awt.*;
import java.time.OffsetDateTime;

public class InfoBotCommand implements ServerCommand {

    @Override
    public void performCommand(Member m, TextChannel channel, Message message) {

        EmbedBuilder builder = new EmbedBuilder();
        builder.setTitle("Info about Bot");
        builder.setColor(Color.CYAN);
        builder.setTimestamp(OffsetDateTime.now());
        builder.addField("Bot: ", "Geative", true);
        builder.addField("Version: ", "1.0 Beta", true);
        builder.addField("JDA-Version: ", "4.3.0_295", true);
        builder.addField("Member: ", String.valueOf(m.getGuild().getMembers().size()), true);
        builder.addField("Developer: ", "@Paxl_Plays#8621", true);

        channel.sendMessage(builder.build()).queue();

    }
}
