package de.geative.Commands;

import de.geative.Geative;
import de.geative.Management.CommandListener;
import de.geative.Management.ServerCommand;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import java.awt.*;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalUnit;
import java.util.concurrent.TimeUnit;

public class PingCommand extends ListenerAdapter {
    private JDA jda;
    public void onMessageReceived(MessageReceivedEvent event) {
        String args = event.getMessage().getContentDisplay();
        if(args.startsWith(Geative.INSTANCE.Prefix + "ping")) {


            EmbedBuilder builder = new EmbedBuilder();
            builder.setTitle("Ping");
            builder.setColor(Color.cyan);
            builder.setTimestamp(OffsetDateTime.now());
            builder.setDescription("Ping: " + event.getJDA().getGatewayPing() + "ms | ");
            event.getChannel().sendMessage(builder.build()).queue();
            event.getMessage().delete().queue();
        }
    }
}
