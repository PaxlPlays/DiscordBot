package de.geative.Datenbank;

import de.geative.Management.Config;

public class SQLManager {
    public static void onCreate() {

        //id   guildid   channelid   messageid   emote   rollenid

        //LiteSQL.onUpdate("CREATE TABLE IF NOT EXISTS reactroles(id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, guildid INTEGER, channelid INTEGER, messageid INTEGER, emote VARCHAR, rollenid INTEGER)");



        // LiteSQL.onUpdate("CREATE TABLE IF NOT EXISTS timeranks(id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, userid INTEGER, guildid INTEGER, time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");


        //LiteSQL.onUpdate("CREATE TABLE IF NOT EXISTS statchannels(id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, guildid INTEGER, categoryid INTEGER)");


        final String defaultvolume = Config.get("VOLUME");
        final String defaultsender = "#original";

        final String defaultPrefix = Config.get("prefix");
        LiteSQL.onUpdate("CREATE TABLE IF NOT EXISTS guild_settings (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "guild_id VARCHAR(20) NOT NULL," +
                "prefix VARCHAR(255) NOT NULL DEFAULT '" + defaultPrefix + "'" +
                ");");

        LiteSQL.onUpdate("CREATE TABLE IF NOT EXISTS language(id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, userid INTEGER, emote INTEGER)");
    }
}
