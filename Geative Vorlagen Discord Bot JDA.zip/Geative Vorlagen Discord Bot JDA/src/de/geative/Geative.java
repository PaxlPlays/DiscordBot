package de.geative;

import com.jagrosh.jdautilities.commons.waiter.EventWaiter;
import de.geative.Commands.PingCommand;
import de.geative.Datenbank.LiteSQL;
import de.geative.Datenbank.SQLManager;
import de.geative.Listener.GiveawayEvent;
import de.geative.Listener.HelpReaktionListener;
import de.geative.Listener.LanguageCheckEvent;
import de.geative.Listener.LanguageReaktionListener;
import de.geative.Management.CommandListener;
import de.geative.Management.CommandManager;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.requests.GatewayIntent;
import net.dv8tion.jda.api.sharding.DefaultShardManagerBuilder;
import net.dv8tion.jda.api.sharding.ShardManager;
import net.dv8tion.jda.api.utils.MemberCachePolicy;

import javax.crypto.spec.SecretKeySpec;
import javax.security.auth.login.LoginException;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Properties;

public class Geative {

    public static Geative INSTANCE;

    public ShardManager shardman;
    private final CommandManager cmdMan;
    public Thread loop;
    public  String Tokenid;
    public  String Prefix;
    public File config;
    public File folder1;
    public JDA jda;
    public static final String ANSI_YELLOW = "\u001B[33m";

    public static void main(String[] args) throws IllegalArgumentException {
        try {
            new Geative();
        } catch (LoginException | IllegalArgumentException | SQLException e) {
            e.printStackTrace();
        }
    }

    public Geative() throws LoginException, IllegalArgumentException, SQLException {
        INSTANCE = this;
        LiteSQL.connect();
        SQLManager.onCreate();



        EventWaiter waiter = new EventWaiter();
        this.cmdMan = new CommandManager(waiter);


        loadConfig();


        try (FileReader reader = new FileReader(config)) {
            Properties properties = new Properties();
            properties.load(reader);
            Tokenid = properties.getProperty("Token");
            Prefix = properties.getProperty("Prefix");

        } catch (Exception e) {
            e.printStackTrace();
        }



        DefaultShardManagerBuilder builder = DefaultShardManagerBuilder.createDefault(Tokenid);
        builder.setActivity(Activity.playing("Geative"));
        builder.setStatus(OnlineStatus.ONLINE);
        builder.setAutoReconnect(true);
        builder.setShardsTotal(3).build();
        builder.setShards(2).build();




        builder.addEventListeners(new CommandListener(waiter), waiter);
        builder.addEventListeners(new LanguageReaktionListener());
        builder.addEventListeners(new LanguageCheckEvent());
        builder.addEventListeners(new HelpReaktionListener());
        builder.addEventListeners(new PingCommand());





        shutdown();


        this.shardman = builder.build();

        System.out.println("Bot online.");


    }

    public void shutdown() {

        new Thread(() -> {

            String line = "";
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            try {
                while ((line = reader.readLine()) != null) {

                    if (line.equalsIgnoreCase("exit")) {
                        if (shardman != null) {
                            shardman.setStatus(OnlineStatus.OFFLINE);
                            shardman.shutdown();
                            LiteSQL.disconnect();

                            System.out.println("Bot offline");
                        }

                        if (loop != null) {
                            loop.interrupt();
                        }

                        reader.close();

                    } else {
                        System.out.println("Use 'exit' to shutdown.");

                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }


        }).start();

    }

    public void shutdown2() {

        new Thread(() -> {

            String line = "";
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            try {
                while ((line = reader.readLine()) != null) {



                        shardman.setStatus(OnlineStatus.OFFLINE);
                        shardman.shutdown();
                        LiteSQL.disconnect();

                        System.out.println("Bot offline");

                        loop.interrupt();
                    reader.close();

                }
                }catch (IOException e) {
                    e.printStackTrace();
                }


        }).start();
        }


    public void loadConfig() {


        System.out.println("\nisFileAvailable Methode wird aufgerufen: ");

        folder1 = new File("config");
        config = new File("config/config.txt");


        if (folder1.exists()) {
            System.out.println("Config Ordner  existieren.");

        } else {
            folder1.mkdirs();
            System.out.println("Config Ordner wurde erstellt.");
        }
        if (config.exists()) {
            System.out.println("Config Datei existieren.");


        } else {
            try {
                config.createNewFile();
                System.out.println("Config Datei wurde erstellt.");
            } catch (IOException e) {

                e.printStackTrace();
            }



            try {
                OutputStream stream = new FileOutputStream(config);

                String configtext = "Token=Hier kommt der Token hin\r\nPrefix=Hier kommt der Token hin";


                try {
                    stream.write(configtext.getBytes(StandardCharsets.UTF_8));
                    stream.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }


        }
        if(Tokenid == "Hier kommt der Token hin" | Prefix == "Hier kommt der Prefix hin") {
            System.out.println(ANSI_YELLOW + "Bearbeite bitte die Config im Ordner Config und starte den Bot neu. **Keine Leerzeichen**  \n"
                    + ANSI_YELLOW + "Please edit the config in the Config folder and restart the bot. **No spaces**");
        } else if(Tokenid == "Hier kommt der Token hin" ) {
            System.out.println(ANSI_YELLOW + "Token fehlt !!! Bearbeite bitte die Config im Ordner Config und starte den Bot neu. **Keine Leerzeichen**  \n"
                    + ANSI_YELLOW + "Token is missing !!! Please edit the config in the Config folder and restart the bot. **No spaces**");
        } else if(Prefix == "Hier kommt der Prefix hin") {
            System.out.println(ANSI_YELLOW + "Prefix fehlt !!! Bearbeite bitte die Config im Ordner Config und starte den Bot neu. **Keine Leerzeichen**  \n"
                    + ANSI_YELLOW + "Prefix is missing !!! Please edit the config in the Config folder and restart the bot. **No spaces**");
        }


    }


    public CommandManager getCmdMan() {

        return cmdMan;
    }
}

