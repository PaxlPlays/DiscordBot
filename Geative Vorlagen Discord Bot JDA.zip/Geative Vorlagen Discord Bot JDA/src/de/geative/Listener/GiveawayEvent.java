package de.geative.Listener;

import com.jagrosh.jdautilities.commons.waiter.EventWaiter;
import de.geative.Commands.GiveawayCommand;
import de.geative.Geative;
import de.geative.Management.ServerCommand;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.*;


public class GiveawayEvent implements ServerCommand {
    private final EventWaiter waiter;

    public GiveawayEvent(EventWaiter waiter) {
        this.waiter = waiter;
    }


    @Override
    public void performCommand(Member m, TextChannel channel, Message message) {
        final TextChannel channel2 = channel;



/*
            //= arg0 arg1 arg2...
                EmbedBuilder builder = new EmbedBuilder();
                builder.setDescription("Bitte gebe den Channel an wo das giveaway gehosted werden soll *** #channel ***");
                builder.appendDescription("\uD83C\uDF89");
                channel2.sendMessage(builder.build()).queue(message3 -> {
                    message3.getContentDisplay();



            this.waiter.waitForEvent(
                    MessageReceivedEvent.class,
                    (e) -> e.getChannel().getIdLong() == channel.getIdLong() && e.getMessage().getContentDisplay().startsWith("#"),
                    (e) -> {
                        e.getChannel().sendMessage("Das giveaway findet im Channel **" + e.getMessage().getContentDisplay() + "**  statt.").queue();

                        //Time
                        int zahl = 0;
                        channel.sendMessage("Wie lange soll das Giveaway gehen? (in Tage)").queue(
                                    this.waiter.waitForEvent(
                                            MessageReceivedEvent.class,
                                            (f) -> e.getChannel().getIdLong() == channel.getIdLong() && e.getMessage().getContentDisplay().startsWith("#"),
                                            (f) -> { e.getChannel().sendMessage("Das giveaway dauert **" + e.getMessage().getContentDisplay().startsWith("'") + "**  Tage.").queue();






                    }, 15L, TimeUnit.SECONDS,
                    () -> channel.sendMessage("Du hast zu lange gewartet.").queue()

                                    )};
                    ;});
                    });
    }
}






            /**
             if(message.startsWith("#")) {
             EmbedBuilder builder =  new EmbedBuilder();
             builder.setDescription("Wie lange soll das giveway gehen?  *** z.b: d4 *** (4 Tage");
             event.getTextChannel().sendMessage(builder.getDescriptionBuilder()).queue();
             }
             if(message.startsWith("d")) {
             EmbedBuilder builder =  new EmbedBuilder();
             builder.setDescription("Wie viele Gewinner sollen gezogen werden? *** Winner 2 **");
             event.getTextChannel().sendMessage(builder.getDescriptionBuilder()).queue();
             }
             if(message.startsWith("Winner")) {
             EmbedBuilder builder =  new EmbedBuilder();
             builder.setDescription("Was ist der Preis vom Giveaway");
             event.getTextChannel().sendMessage(builder.getDescriptionBuilder()).queue();
             }
             **/
                }
        }










