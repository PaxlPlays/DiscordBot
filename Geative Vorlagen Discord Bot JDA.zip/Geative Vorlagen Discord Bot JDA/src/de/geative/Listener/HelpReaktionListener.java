package de.geative.Listener;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.ChannelType;
import net.dv8tion.jda.api.entities.Emote;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.MessageReaction;
import net.dv8tion.jda.api.events.message.react.MessageReactionAddEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.jetbrains.annotations.NotNull;

import java.awt.*;
import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.List;

public class HelpReaktionListener extends ListenerAdapter {

    @Override
    public void onMessageReactionAdd(@NotNull MessageReactionAddEvent event) {


        String i = event.getReactionEmote().getName();

        if(event.getChannelType() == ChannelType.TEXT) {
            if(!event.getUser().isBot()) {
                if(event.getReactionEmote().getName().equals(i))

                switch(i) {
                    ////Einstellungen
                case "\uD83C\uDF9A":
                    EmbedBuilder builder = new EmbedBuilder();
                    builder.setTitle("Einstellungen");
                    builder.setColor(Color.CYAN);
                    builder.setTimestamp(OffsetDateTime.now());
                    builder.addField("\uD83C\uDDE9\uD83C\uDDEA Sprache", "", false);
                    builder.addField("\uD83E\uDE9B Prefix", "", false);
                    builder.addField("↩ Zurück", "", false);
                    event.getChannel().editMessageById(event.getMessageId(), builder.build()).queue(message2 -> {
                        message2.addReaction("\uD83C\uDFF3️\u200D\uD83C\uDF08").queue();
                        message2.addReaction("\uD83E\uDE9B").queue();
                        message2.addReaction("↩️").queue();
                        message2.removeReaction("\uD83C\uDF9A").queue();
                        message2.removeReaction("\uD83C\uDF9A").queue();
                        message2.removeReaction("\uD83C\uDFB5").queue();
                        message2.removeReaction("\uD83C\uDF9B").queue();
                        message2.removeReaction("\uD83D\uDDC3").queue();
                        message2.removeReaction("\uD83D\uDCE1").queue();
                        message2.removeReaction("\uD83D\uDCE8").queue();
                        message2.removeReaction(i).queue();

                    });
                    break;
                    ///Musik
                case "\uD83C\uDFB5" :
                    EmbedBuilder builder2 = new EmbedBuilder();
                    builder2.setTitle("Musik");
                    builder2.setColor(Color.CYAN);
                    builder2.setTimestamp(OffsetDateTime.now());
                    builder2.setDescription("**Commands**\n" +
                                            "=join ---> Bot joint Channel" +
                                            "\n" +
                                            "=play <link> ---> Formate: Youtube, Twitch, Soundcloud." +
                                            "\n" +
                                            "=skip ---> Bei einer Queue wird der nächste Song gespielt." +
                                            "\n" +
                                            "=queue ---> Anzeige anzahl der Lieder in der Playlist." +
                                            "\n" +
                                            "=nowplaying ---> Welches Lied gerade gespielt wird." +
                                            "\n" +
                                            "\n" +
                                            "=stop ---> Stoppt den Song." +
                                            "\n" +
                                            "=leave ---> Bot verlässt Channel.");
                    event.getChannel().editMessageById(event.getMessageId(), builder2.build()).queue(message3 -> {
                        message3.addReaction("↩️").queue();
                        message3.removeReaction("\uD83C\uDF9A").queue();
                        message3.removeReaction("\uD83C\uDFB5").queue();
                        message3.removeReaction("\uD83C\uDF9B").queue();
                        message3.removeReaction("\uD83D\uDDC3").queue();
                        message3.removeReaction("\uD83D\uDCE1").queue();
                        message3.removeReaction("\uD83D\uDCE8").queue();
                    });
                    break;
                    ///Commands
                    case "\uD83C\uDF9B" :
                        EmbedBuilder builder3 = new EmbedBuilder();
                        builder3.setTitle("Allgemeine Commands");
                        builder3.setColor(Color.CYAN);
                        builder3.setTimestamp(OffsetDateTime.now());
                        builder3.setDescription("**Commands**\n" +
                                "=join ---> Bot joint Channel" +
                                "\n" +
                                "=play <link> ---> Formate: Youtube, Twitch, Soundcloud." +
                                "\n" +
                                "=skip ---> Bei einer Queue wird der nächste Song gespielt." +
                                "\n" +
                                "=queue ---> Anzeige anzahl der Lieder in der Playlist." +
                                "\n" +
                                "=nowplaying ---> Welches Lied gerade gespielt wird." +
                                "\n" +
                                "\n" +
                                "=stop ---> Stoppt den Song." +
                                "\n" +
                                "=leave ---> Bot verlässt Channel.");
                        event.getChannel().editMessageById(event.getMessageId(), builder3.build()).queue(message3 -> {
                            message3.addReaction("↩️").queue();
                            message3.removeReaction("\uD83C\uDF9A").queue();
                            message3.removeReaction("\uD83C\uDFB5").queue();
                            message3.removeReaction("\uD83C\uDF9B").queue();
                            message3.removeReaction("\uD83D\uDDC3").queue();
                            message3.removeReaction("\uD83D\uDCE1").queue();
                            message3.removeReaction("\uD83D\uDCE8").queue();
                        });
                        break;
                        ///User-info
                    case "\uD83D\uDDC3" :
                        EmbedBuilder builder4 = new EmbedBuilder();
                        builder4.setTitle("Info about Bot");
                        builder4.setColor(Color.CYAN);
                        builder4.setTimestamp(OffsetDateTime.now());
                        builder4.addField("Name: ", event.getUser().getName(), false);
                        builder4.addField("Nickname: ", event.getMember().getNickname(), false);
                        builder4.addField("Status: ", event.getMember().getOnlineStatus().toString(), true);
                        builder4.addField("Game:  ", String.valueOf(event.getMember().getGuild().getMembers().size()), true);
                        builder4.addField("Developer: ", "@Paxl_Plays#8621", true);

                        event.getChannel().sendMessage(builder4.build()).queue(message4 -> {
                            message4.addReaction("↩️").queue();
                            message4.removeReaction("\uD83C\uDF9A").queue();
                            message4.removeReaction("\uD83C\uDFB5").queue();
                            message4.removeReaction("\uD83C\uDF9B").queue();
                            message4.removeReaction("\uD83D\uDDC3").queue();
                            message4.removeReaction("\uD83D\uDCE1").queue();
                            message4.removeReaction("\uD83D\uDCE8").queue();
                        });
                        break;
                    case "\uD83D\uDCE1" :
                        EmbedBuilder builder5 = new EmbedBuilder();
                        builder5.setTitle("Info about Bot");
                        builder5.setColor(Color.CYAN);
                        builder5.setTimestamp(OffsetDateTime.now());
                        builder5.addField("Bot ", "Geative", true);
                        builder5.addField("Version ", "1.0 Beta", false);
                        builder5.addField("JDA-Version ", "4.3.0_295", false);
                        builder5.addField("Member ", String.valueOf(event.getMember().getGuild().getMembers().size()), true);
                        builder5.addField("Ersteller ", "@Paxl_Plays#8621", false);
                        builder5.addField("Server: ", String.valueOf(event.getJDA().getGuilds().size()), false);
                        builder5.addField("Allgemine User Anzahl ", String.valueOf(event.getJDA().getUsers().size()), false);
                        event.getChannel().editMessageById(event.getMessageId(), builder5.build()).queue(message5 -> {
                            message5.addReaction("↩️").queue();
                            message5.removeReaction("\uD83C\uDF9A").queue();
                            message5.removeReaction("\uD83C\uDFB5").queue();
                            message5.removeReaction("\uD83C\uDF9B").queue();
                            message5.removeReaction("\uD83D\uDDC3").queue();
                            message5.removeReaction("\uD83D\uDCE1").queue();
                            message5.removeReaction("\uD83D\uDCE8").queue();
                        });
                        break;
                    ///Commands
                    case "\uD83D\uDCE8" :
                        EmbedBuilder builder6 = new EmbedBuilder();
                        builder6.setTitle("Kontakt");
                        builder6.setColor(Color.CYAN);
                        builder6.setTimestamp(OffsetDateTime.now());
                        builder6.setDescription("*Social Media*\n" +
                                "**Twiter** ---> " +
                                "\n" +
                                "**Discord** ---> " +
                                "\n" +
                                "**Website** ---> " +
                                "\n" +
                                "\n" +
                                "*Bot*" +
                                "\n" +
                                "*Vote* ---> " +
                                "\n" +
                                "invite ---> " );
                        event.getChannel().editMessageById(event.getMessageId(), builder6.build()).queue(message6 -> {
                            message6.addReaction("↩️").queue();
                            message6.removeReaction("\uD83C\uDF9A").queue();
                            message6.removeReaction("\uD83C\uDFB5").queue();
                            message6.removeReaction("\uD83C\uDF9B").queue();
                            message6.removeReaction("\uD83D\uDDC3").queue();
                            message6.removeReaction("\uD83D\uDCE1").queue();
                            message6.removeReaction("\uD83D\uDCE8").queue();
                        });
                        break;

                        //Language
                    case"\uD83C\uDFF3️\u200D\uD83C\uDF08":
                        EmbedBuilder builder7 = new EmbedBuilder();
                        builder7.setTitle("Sprache einstellen");
                        builder7.setColor(Color.CYAN);
                        builder7.setTimestamp(OffsetDateTime.now());
                        builder7.setDescription("Set the language for the bot, you can choose between: \n"
                                + "\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67\uDB40\uDC7F English\n"
                                + "\uD83C\uDDE9\uD83C\uDDEA Deutsch");
                        builder7.setColor(Color.CYAN);
                        event.getChannel().editMessageById(event.getMessageId(), builder7.build()).queue(mess -> {
                            mess.addReaction("\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67\uDB40\uDC7F").queue();
                            mess.addReaction("\uD83C\uDDE9\uD83C\uDDEA").queue();
                            mess.addReaction("↩️").queue();
                            mess.removeReaction("\uD83C\uDF9A").queue();
                            mess.removeReaction("\uD83C\uDFB5").queue();
                            mess.removeReaction("\uD83C\uDF9B").queue();
                            mess.removeReaction("\uD83D\uDDC3").queue();
                            mess.removeReaction("\uD83D\uDCE1").queue();
                            mess.removeReaction("\uD83D\uDCE8").queue();
                        });
                        break;

                        //Prefix

                    case"\uD83E\uDE9B":
                        EmbedBuilder builder8 = new EmbedBuilder();
                        builder8.setTitle("Prefix einstellen");
                        builder8.setColor(Color.CYAN);
                        builder8.setTimestamp(OffsetDateTime.now());
                        builder8.setDescription("Schreibe dein Prefix den du haben willst. Ich empfehle ---> + , - , = , &, % oder * (**aber bitte keine Buchstaben oder Wörter oder /), sonst kann es zu Problemen kommen!!!**\n"
                                + "\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67\uDB40\uDC7F English\n"
                                + "\uD83C\uDDE9\uD83C\uDDEA Deutsch");
                        builder8.setColor(Color.CYAN);
                        event.getChannel().editMessageById(event.getMessageId(), builder8.build()).queue(mess2 -> {
                            mess2.addReaction("\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67\uDB40\uDC7F").queue();
                            mess2.addReaction("\uD83C\uDDE9\uD83C\uDDEA").queue();
                            mess2.addReaction("↩️").queue();
                            mess2.removeReaction("\uD83C\uDF9A").queue();
                            mess2.removeReaction("\uD83C\uDFB5").queue();
                            mess2.removeReaction("\uD83C\uDF9B").queue();
                            mess2.removeReaction("\uD83D\uDDC3").queue();
                            mess2.removeReaction("\uD83D\uDCE1").queue();
                            mess2.removeReaction("\uD83D\uDCE8").queue();
                            mess2.getReactions().remove(event.getReaction());
                        });


                        break;

                    ////Einstellungen
                    case "↩️":
                        EmbedBuilder builder10 = new EmbedBuilder();
                        builder10.setTitle("Einstellungen ");
                        builder10.setColor(Color.CYAN);
                        builder10.setTimestamp(OffsetDateTime.now());
                        builder10.addField("\uD83C\uDF9A Einstellungen", " ", false);
                        builder10.addField("\uD83C\uDFB5 Musik", " ", false);
                        builder10.addField("\uD83C\uDF9B Commands", " ", false);
                        builder10.addField("\uD83D\uDDC3 Profil", " ", false);
                        builder10.addField("\uD83D\uDCE1 Informationen", " ", false);
                        builder10.addField("\uD83D\uDCE8 Kontakt", " ", false);
                        event.getChannel().editMessageById(event.getMessageId(), builder10.build()).queue(message10 -> {
                            message10.addReaction("\uD83C\uDF9A").queue();
                            message10.addReaction("\uD83C\uDFB5").queue();
                            message10.addReaction("\uD83C\uDF9B").queue();
                            message10.addReaction("\uD83D\uDDC3").queue();
                            message10.addReaction("\uD83D\uDCE1").queue();
                            message10.addReaction("\uD83D\uDCE8").queue();
                            message10.removeReaction("\uD83C\uDFF3️\u200D\uD83C\uDF08").queue();
                            message10.removeReaction("\uD83E\uDE9B").queue();
                        });
                        break;
                }
            }
        }
    }
}
