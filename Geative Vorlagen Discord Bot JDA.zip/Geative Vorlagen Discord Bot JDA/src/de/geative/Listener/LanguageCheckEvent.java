package de.geative.Listener;

import de.geative.Datenbank.LiteSQL;
import de.geative.Geative;
import net.dv8tion.jda.api.entities.ChannelType;
import net.dv8tion.jda.api.entities.TextChannel;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import java.sql.ResultSet;
import java.sql.SQLException;

public class LanguageCheckEvent extends ListenerAdapter {

    public ResultSet set;

    public void onMessageReceived(MessageReceivedEvent event) {


        String message = event.getMessage().getContentDisplay();

        if (event.isFromType(ChannelType.TEXT)) {
            TextChannel channel = event.getTextChannel();

            //= arg0 arg1 arg2...
            if (message.startsWith(Geative.INSTANCE.Prefix)) {


                ResultSet set = null;
                try {

                    long userid = event.getMember().getUser().getIdLong();


                    set = LiteSQL.onQuery("SELECT userid FROM language WHERE userid =" + userid);


                    try {
                        String englisch = "\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67\uDB40\uDC7F";
                        if (set.next()) {
                            LiteSQL.onQuery("SELECT emote FROM language WHERE userid =" + userid);
                         if(set.getObject("emote") == englisch) {

                         }

                        }

                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                } finally {
                    try {
                        set.close();
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }


                }
            }
        }

    }
}
