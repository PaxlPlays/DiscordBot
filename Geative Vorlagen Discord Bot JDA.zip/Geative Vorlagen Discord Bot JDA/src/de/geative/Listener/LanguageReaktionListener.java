package de.geative.Listener;

import de.geative.Datenbank.LiteSQL;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.ChannelType;
import net.dv8tion.jda.api.events.message.react.MessageReactionAddEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.OffsetDateTime;

public class LanguageReaktionListener extends ListenerAdapter {

    public void onMessageReactionAdd(MessageReactionAddEvent event) {
        if (event.getChannelType() == ChannelType.TEXT) {
            if (!event.getUser().isBot()) {
                if (event.getReactionEmote().getEmoji().equals("\uD83C\uDDE9\uD83C\uDDEA")) {

                    ResultSet set = null;
                    try {

                        long userid = event.getUser().getIdLong();



                        set = LiteSQL.onQuery("SELECT userid FROM language WHERE userid =" + userid);


                        try {
                            String language = "deutsch";
                            if (set.next()) {
                                LiteSQL.onUpdate("UPDATE language SET emote = '" + language + "' WHERE userid = " + userid + " ");
                                String afterautoplaychannel = null;
                                String newautoplaychannel = null;


                            } else
                                LiteSQL.onUpdate("INSERT INTO language (userid, emote) VALUES (" + userid + ", '" + language + "')");

                        } catch (SQLException throwables) {
                            throwables.printStackTrace();
                        }
                    } finally {
                        try {
                            set.close();
                        } catch (SQLException throwables) {
                            throwables.printStackTrace();
                        }
                        EmbedBuilder builder = new EmbedBuilder();
                        builder.setTitle("Sprache");
                        builder.setDescription("Sprache wurde auf Deutsch gesetzt");
                        builder.setFooter("www.traplinefm.at", "https://s16.directupload.net/images/210226/t4r65ys3.png");
                        builder.setTimestamp(OffsetDateTime.now());
                        builder.setColor(Color.CYAN);

                        event.getTextChannel().editMessageById(event.getMessageId(), builder.getDescriptionBuilder()).queue();
                    }

                } else if (event.getReactionEmote().getEmoji().equals("\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67\uDB40\uDC7F")) {
                    ResultSet set = null;
                    try {

                        long userid = event.getUser().getIdLong();


                        set = LiteSQL.onQuery("SELECT userid FROM language WHERE userid =" + userid);


                        try {
                            String language = "englisch";
                            if (set.next()) {
                                LiteSQL.onUpdate("UPDATE language SET emote = '" + language + "' WHERE userid = " + userid + " ");
                                String afterautoplaychannel = null;
                                String newautoplaychannel = null;


                            } else
                                LiteSQL.onUpdate("INSERT INTO language (userid, emote) VALUES (" + userid + ", '" + language + "')");

                        } catch (SQLException throwables) {
                            throwables.printStackTrace();
                        }
                    } finally {
                        try {
                            set.close();
                        } catch (SQLException throwables) {
                            throwables.printStackTrace();
                        }
                        EmbedBuilder builder = new EmbedBuilder();
                        builder.setTitle("Language");
                        builder.setDescription("Language was set to English");
                        builder.setFooter("www.traplinefm.at", "https://s16.directupload.net/images/210226/t4r65ys3.png");
                        builder.setTimestamp(OffsetDateTime.now());
                        builder.setColor(Color.CYAN);

                        event.getTextChannel().editMessageById(event.getMessageId(),builder.getDescriptionBuilder()).queue();
                    }
                }
            }

        }
    }
}
