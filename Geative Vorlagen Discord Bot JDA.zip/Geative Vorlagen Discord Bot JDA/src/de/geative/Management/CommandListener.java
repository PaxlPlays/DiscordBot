package de.geative.Management;

import com.jagrosh.jdautilities.commons.waiter.EventWaiter;
import de.geative.Geative;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.ChannelType;
import net.dv8tion.jda.api.entities.TextChannel;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import java.awt.*;

public class CommandListener extends ListenerAdapter {

    private final CommandManager manager;

    public CommandListener(EventWaiter waiter) {
        manager = new CommandManager(waiter);
    }

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {



        String message = event.getMessage().getContentDisplay();



        if (event.isFromType(ChannelType.TEXT)) {
            TextChannel channel = event.getTextChannel();

            //= arg0 arg1 arg2...
            if (message.startsWith(Geative.INSTANCE.Prefix)) {

                String[] args = message.substring(1).split(" ");

                if (args.length > 0) {
                    if (!Geative.INSTANCE.getCmdMan().perform(args[0], event.getMember(), channel, event.getMessage())) {
                        EmbedBuilder builder = new EmbedBuilder();
                        builder.setDescription("Unbekannter Command");
                        builder.setColor(Color.red);
                        channel.sendMessage(builder.getDescriptionBuilder()).queue();
                    }

                }


            }

        }


    }
}

