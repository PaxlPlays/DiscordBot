package de.geative.Management;

import com.jagrosh.jdautilities.command.CommandEvent;
import com.jagrosh.jdautilities.commons.waiter.EventWaiter;
import de.geative.Commands.HelpCommand;
import de.geative.Commands.InfoBotCommand;
import de.geative.Commands.PingCommand;
import de.geative.Listener.GiveawayEvent;
import de.geative.Moderator.KickCommand;
import de.geative.Musik.Commands.*;
import de.geative.Settings.LanguageCommand;
import de.geative.Settings.ShutdownCommand;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;

import java.util.concurrent.ConcurrentHashMap;

public class CommandManager {
    public ConcurrentHashMap<String, ServerCommand> commands;


    public CommandManager(EventWaiter waiter) {
        this.commands = new ConcurrentHashMap<>();

        //Musik
        this.commands.put("play", new PlayCommand());
        this.commands.put("join", new JoinCommand());
        this.commands.put("stop", new StopCommand());
        this.commands.put("skip", new SkipCommand());
        this.commands.put("leave", new LeaveCommand());
        this.commands.put("nowplaying", new NowPlayingCommand());
        this.commands.put("queue", new QueueCommand());

        //Moderation
        this.commands.put("kick", new KickCommand());

        //Settings
        this.commands.put("language", new LanguageCommand());
        this.commands.put("shutdown", new ShutdownCommand());

        this.commands.put("giveaway", new GiveawayEvent(waiter));
        this.commands.put("botinfo", new InfoBotCommand());
        this.commands.put("help", new HelpCommand());




    }


    public boolean perform(String command, Member m, TextChannel channel, Message message) {

        ServerCommand cmd;
        if ((cmd = this.commands.get(command.toLowerCase())) != null) {
            cmd.performCommand(m, channel, message);
            return true;
        }
        return false;
    }

}
