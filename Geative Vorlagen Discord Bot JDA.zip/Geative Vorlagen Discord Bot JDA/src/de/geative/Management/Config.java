package de.geative.Management;

import io.github.cdimascio.dotenv.Dotenv;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class Config {

    private static final Dotenv dotenv = Dotenv.load();




    public static String get(String key) {
        return dotenv.get(key.toUpperCase());
    }

}


