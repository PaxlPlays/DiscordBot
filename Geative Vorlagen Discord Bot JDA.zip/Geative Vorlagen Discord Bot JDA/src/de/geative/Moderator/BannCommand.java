package de.geative.Moderator;

import de.geative.Management.ServerCommand;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;

import java.awt.*;
import java.util.Arrays;
import java.util.List;

public class BannCommand implements ServerCommand {


    @Override
    public void performCommand(Member m, TextChannel channel, Message message) {
        List<String> args = Arrays.asList(message.getContentDisplay().split(" "));
        final Member target = message.getMentionedMembers().get(0);
        final Member user = message.getMember();


        if (!m.canInteract(target) || !m.hasPermission(Permission.BAN_MEMBERS)) {
            EmbedBuilder builder = new EmbedBuilder();
            builder.setColor(Color.RED);
            builder.setTitle("User ban");
            builder.setDescription("Du hast dafür keine Rechte.");

            channel.sendMessage((CharSequence) builder.build());
        }

        final Member selfMember = m.getGuild().getSelfMember();

        if (!selfMember.canInteract(target) || !selfMember.hasPermission(Permission.BAN_MEMBERS)) {
            EmbedBuilder builder = new EmbedBuilder();
            builder.setColor(Color.RED);
            builder.setTitle("User ban");
            builder.setDescription("ich habe dafür keine Rechte.");

            channel.sendMessage((CharSequence) builder.build());
        }


        if (args.size() > 1) {
            channel.sendMessage("Missing Arguments").queue();
            return;
        }

        int days = 0;

        String reason = "";
        try {
            days = Integer.parseInt(args.get(1));

        } catch (Exception e) {

        }

        try {
            if (days == 0) {
                reason = String.join(" ", args.subList(1, args.size()));
            } else {
                reason = String.join(" ", args.subList(2, args.size()));
            }
        } catch (Exception e) {

        }

        try {
            target.ban(days == 0 ? days : 0, reason == "" ? null : reason).queue();
            EmbedBuilder builder = new EmbedBuilder();
            builder.setTitle(target.getAsMention() + " wurde gebannt für " + days + " Tage");
            builder.setDescription("Grund: " + reason);
            channel.sendMessage((CharSequence) builder.build()).queue();

        }catch (Exception e ) {

        }

            return;


        }
    }
