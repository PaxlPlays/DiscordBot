package de.geative.Moderator;

import de.geative.Management.ServerCommand;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;

import java.awt.*;

public class KickCommand implements ServerCommand {
    @Override
    public void performCommand(Member m, TextChannel channel, Message message) {

        String[] args = message.getContentDisplay().split(" ");
        final Member target = message.getMentionedMembers().get(0);
        final Member user   = message.getMember();
        final String reason = String.join(" ", args[2]);


        if (!m.canInteract(target) || !m.hasPermission(Permission.KICK_MEMBERS)) {
            EmbedBuilder builder = new EmbedBuilder();
            builder.setColor(Color.RED);
            builder.setTitle("User kicken");
            builder.setDescription("Du hast dafür keine Rechte.");

            channel.sendMessage(builder.getDescriptionBuilder());
        }

        final Member selfMember = m.getGuild().getSelfMember();

        if (!selfMember.canInteract(target) || !selfMember.hasPermission(Permission.KICK_MEMBERS)) {
            EmbedBuilder builder = new EmbedBuilder();
            builder.setColor(Color.RED);
            builder.setTitle("User kicken");
            builder.setDescription("ich habe dafür keine Rechte.");

            channel.sendMessage(builder.getDescriptionBuilder());
        }



        if (args.length < 2 || message.getMentionedMembers().isEmpty()) {
            channel.sendMessage("Missing Arguments").queue();
            return;
        }


        m.getGuild()
                .kick(target, reason)
                .reason(reason)
                .queue();

        EmbedBuilder builder = new EmbedBuilder();
        builder.setTitle(user + " wurde gekickt");
        builder.setDescription("Grund: " + reason);
        channel.sendMessage(builder.getDescriptionBuilder()).queue();

        return;

    }

}

