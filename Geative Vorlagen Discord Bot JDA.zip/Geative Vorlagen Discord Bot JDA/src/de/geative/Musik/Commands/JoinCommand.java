package de.geative.Musik.Commands;

import de.geative.Datenbank.LiteSQL;
import de.geative.Management.ServerCommand;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.*;
import net.dv8tion.jda.api.managers.AudioManager;

import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.OffsetDateTime;
import java.util.concurrent.TimeUnit;

@SuppressWarnings("ConstantConditions")
public class JoinCommand implements ServerCommand {
    @SuppressWarnings("ConstantConditions")
    @Override
    public void performCommand(Member m, TextChannel channel, Message message) {
        final Member self = channel.getGuild().getSelfMember();
        final GuildVoiceState selfVoiceState = self.getVoiceState();

        ResultSet set = null;
        try {

            long userid = m.getUser().getIdLong();


            set = LiteSQL.onQuery("SELECT userid FROM language WHERE userid =" + userid);


            try {
                String englisch = "englisch";
                if (set.next()) {
                    LiteSQL.onQuery("SELECT emote FROM language WHERE userid =" + userid);
                    if ((set.getObject("emote") == englisch)) {

                        if (m.hasPermission(Permission.MANAGE_SERVER) | m.getUser().getId().equals("407881652514324480")) {
                            message.delete().submit();
                            if (selfVoiceState.inVoiceChannel()) {
                                EmbedBuilder builder = new EmbedBuilder();
                                builder.setDescription("I'm already in a voice channel.");
                                builder.setColor(Color.red);
                                channel.sendMessage(builder.build()).queue();
                                return;
                            }

                            final Member member = message.getMember();
                            final GuildVoiceState memberVoiceState = member.getVoiceState();

                            if (!memberVoiceState.inVoiceChannel()) {
                                EmbedBuilder builder = new EmbedBuilder();
                                builder.setDescription("You are not in any language channel to use this command.");
                                builder.setColor(Color.red);
                                channel.sendMessage(builder.build()).queue();
                                return;
                            }

                            final AudioManager audioManager = message.getGuild().getAudioManager();
                            final VoiceChannel memberchannel = member.getVoiceState().getChannel();

                            String voicechannel = member.getVoiceState().getChannel().getName();
                            audioManager.openAudioConnection(memberchannel);
                            EmbedBuilder builder = new EmbedBuilder();
                            builder.setTimestamp(OffsetDateTime.now());
                            builder.setDescription("Connect with ` \uD83D\uDD0A " + voicechannel + "`");
                            builder.setColor(Color.CYAN);
                            channel.sendMessage(builder.build()).queue();

                        } else {
                            EmbedBuilder builder = new EmbedBuilder();
                            builder.setDescription("You have no rights for it!");
                            builder.setColor(Color.red);
                            builder.setTimestamp(OffsetDateTime.now());
                            channel.sendMessage(builder.getDescriptionBuilder()).queue(mess -> {
                                mess.delete().queueAfter(1, TimeUnit.MINUTES);
                            });
                        }

                    } else {
                        if (m.hasPermission(Permission.MANAGE_SERVER) | m.getUser().getId().equals("407881652514324480")) {
                            message.delete().submit();
                            if (selfVoiceState.inVoiceChannel()) {
                                EmbedBuilder builder = new EmbedBuilder();
                                builder.setDescription("Ich bin schon in einem Sprachkanal.");
                                builder.setColor(Color.red);
                                channel.sendMessage(builder.build()).queue();
                                return;
                            }

                            final Member member = message.getMember();
                            final GuildVoiceState memberVoiceState = member.getVoiceState();

                            if (!memberVoiceState.inVoiceChannel()) {
                                EmbedBuilder builder = new EmbedBuilder();
                                builder.setDescription("Du bist in keinem Sprachkanal um diesen Command zu nutzen.");
                                builder.setColor(Color.red);
                                channel.sendMessage(builder.build()).queue();
                                return;
                            }

                            final AudioManager audioManager = message.getGuild().getAudioManager();
                            final VoiceChannel memberchannel = member.getVoiceState().getChannel();

                            String voicechannel = member.getVoiceState().getChannel().getName();
                            audioManager.openAudioConnection(memberchannel);
                            EmbedBuilder builder = new EmbedBuilder();
                            builder.setTimestamp(OffsetDateTime.now());
                            builder.setDescription("Verbunden mit ` \uD83D\uDD0A " + voicechannel + "`");
                            builder.setColor(Color.CYAN);
                            channel.sendMessage(builder.build()).queue();

                        } else {
                            EmbedBuilder builder = new EmbedBuilder();
                            builder.setDescription("Du hast dafür keine Rechte! ");
                            builder.setColor(Color.red);
                            builder.setTimestamp(OffsetDateTime.now());
                            channel.sendMessage(builder.build()).queue(mess -> {
                                mess.delete().queueAfter(1, TimeUnit.MINUTES);
                            });
                        }
                    }

                }

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        } finally {
            try {
                set.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }


        }
    }
    }






