package de.geative.Musik.Commands;

import de.geative.Management.ServerCommand;
import de.geative.Musik.GuildMusicManager;
import de.geative.Musik.PlayerManager;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.*;
import net.dv8tion.jda.api.managers.AudioManager;

import java.awt.*;
import java.time.OffsetDateTime;

public class LeaveCommand implements ServerCommand {
    @Override
    public void performCommand(Member m, TextChannel channel, Message message) {
        final Member self = channel.getGuild().getSelfMember();
        final GuildVoiceState selfVoiceState = self.getVoiceState();

        String[] args = message.getContentDisplay().split(" ");


        if (m.hasPermission(Permission.MANAGE_SERVER) | m.getUser().getId().equals("407881652514324480")) {
            message.delete().submit();
            if (!selfVoiceState.inVoiceChannel()) {
                EmbedBuilder builder = new EmbedBuilder();
                builder.setDescription("Ich bin in keinem Sprachkanal.");
                builder.setColor(Color.red);

                builder.setTimestamp(OffsetDateTime.now());
                channel.sendMessage(builder.build()).queue();
                return;
            }

            final Member member = channel.getGuild().getSelfMember();
            final GuildVoiceState memberVoiceState = member.getVoiceState();

            if (!memberVoiceState.inVoiceChannel()) {
                EmbedBuilder builder = new EmbedBuilder();
                builder.setDescription("Du bist in keinem Sprachkanal.");
                builder.setColor(Color.red);

                builder.setTimestamp(OffsetDateTime.now());
                channel.sendMessage(builder.build()).queue();
                return;
            }

            if (!memberVoiceState.getChannel().equals(selfVoiceState.getChannel())) {
                EmbedBuilder builder = new EmbedBuilder();
                builder.setDescription("Du bist nicht in dem selben Sprachkanal");
                builder.setColor(Color.red);

                builder.setTimestamp(OffsetDateTime.now());
                channel.sendMessage(builder.build()).queue();
                return;
            }

            final AudioManager audioManager = message.getGuild().getAudioManager();
            final VoiceChannel memberchannel = member.getVoiceState().getChannel();
            final GuildMusicManager musicManager = PlayerManager.getInstance().getMusicManager(channel.getGuild());

            musicManager.scheduler.player.stopTrack();
            musicManager.scheduler.queue.clear();

            String voicechannel = member.getVoiceState().getChannel().getName();
            audioManager.closeAudioConnection();
            EmbedBuilder builder = new EmbedBuilder();
            builder.setTimestamp(OffsetDateTime.now());
            builder.setDescription("Verbindung getrennt von` \uD83D\uDD0A " + voicechannel + "`");
            builder.setColor(Color.CYAN);
            channel.sendMessage(builder.build()).queue();
        }
    }

}

