package de.geative.Musik.Commands;


import com.jagrosh.jdautilities.command.CommandEvent;
import de.geative.Geative;
import de.geative.Listener.LanguageCheckEvent;
import de.geative.Management.ServerCommand;
import de.geative.Musik.PlayerManager;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.GuildVoiceState;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;

import java.awt.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.OffsetDateTime;

public class PlayCommand implements ServerCommand {

    @SuppressWarnings("ConstantConditions")
    public void performCommand(Member m, TextChannel channel, Message message) {

        final Member self = channel.getGuild().getSelfMember();
        final GuildVoiceState selfVoiceState = self.getVoiceState();

        String[] args = message.getContentDisplay().split(" ");

        if (m.hasPermission(Permission.MANAGE_SERVER) | m.getUser().getId().equals("407881652514324480")) {
            message.delete().submit();

            if (!selfVoiceState.inVoiceChannel()) {
                EmbedBuilder builder = new EmbedBuilder();
                builder.setDescription("Ich bin in keinem Sprachkanal.");
                builder.setColor(Color.red);

                builder.setTimestamp(OffsetDateTime.now());
                channel.sendMessage(builder.build()).queue();
                return;
            }

            final Member member = channel.getGuild().getSelfMember();
            final GuildVoiceState memberVoiceState = member.getVoiceState();

            if (!memberVoiceState.inVoiceChannel()) {
                EmbedBuilder builder = new EmbedBuilder();
                builder.setDescription("Du bist in keinem Sprachkanal.");
                builder.setColor(Color.red);

                builder.setTimestamp(OffsetDateTime.now());
                channel.sendMessage(builder.build()).queue();
                return;
            }

            if (!memberVoiceState.getChannel().equals(selfVoiceState.getChannel())) {
                EmbedBuilder builder = new EmbedBuilder();
                builder.setDescription("Du bist nicht in dem selben Sprachkanal");
                builder.setColor(Color.red);

                builder.setTimestamp(OffsetDateTime.now());
                channel.sendMessage(builder.build()).queue();
                return;
            }


            String radio = args[1];

            if (args.length > 1) {
                if (!(args[1].startsWith("https://youtube.com") | !(args[1].startsWith("https://www.youtube.com")
                        | !(args[1].startsWith("https://soundcloud.com") | !(args[1].startsWith("https://www.soundcloud.com") | !(args[1].startsWith("https://twitch.tv") | !(args[1].startsWith("https://www.twitch.tv")))))))) {


                    PlayerManager.getInstance().loadAndPlay(channel, args[1]);

                }
                else (channel.sendMessage("Bitte Benutze =play<link> \n"
                        + "link -> YouTube, Soundcloud, Twitch")).queue();

                EmbedBuilder builder = new EmbedBuilder();
                builder.setTimestamp(OffsetDateTime.now());
                builder.setDescription("Bitte Benutze =play<link> \n"
                        + "link -> [YouTube](https://www.youtube.com/), [Soundcloud](https://soundcloud.com/), [Twitch](https://www.twitch.tv/)");
                builder.setColor(Color.CYAN);
                channel.sendMessage(builder.build()).queue();


            }
        }

    }

}

