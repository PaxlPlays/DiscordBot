package de.geative.Musik.Commands;

import com.sedmelluq.discord.lavaplayer.player.AudioPlayer;
import de.geative.Management.ServerCommand;
import de.geative.Musik.GuildMusicManager;
import de.geative.Musik.PlayerManager;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.GuildVoiceState;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;

import java.awt.*;
import java.time.OffsetDateTime;

public class SkipCommand implements ServerCommand {
    @Override
    public void performCommand(Member m, TextChannel channel, Message message) {

        final Member self = channel.getGuild().getSelfMember();
        final GuildVoiceState selfVoiceState = self.getVoiceState();

        String[] args = message.getContentDisplay().split(" ");


        if (m.hasPermission(Permission.MANAGE_SERVER) | m.getUser().getId().equals("407881652514324480")) {
            message.delete().submit();
            if (!selfVoiceState.inVoiceChannel()) {
                EmbedBuilder builder = new EmbedBuilder();
                builder.setDescription("Ich bin in keinem Sprachkanal.");
                builder.setColor(Color.red);

                builder.setTimestamp(OffsetDateTime.now());
                channel.sendMessage(builder.build()).queue();
                return;
            }

            final Member member = channel.getGuild().getSelfMember();
            final GuildVoiceState memberVoiceState = member.getVoiceState();

            if (!memberVoiceState.inVoiceChannel()) {
                EmbedBuilder builder = new EmbedBuilder();
                builder.setDescription("Du bist in keinem Sprachkanal.");
                builder.setColor(Color.red);

                builder.setTimestamp(OffsetDateTime.now());
                channel.sendMessage(builder.build()).queue();
                return;
            }

            if (!memberVoiceState.getChannel().equals(selfVoiceState.getChannel())) {
                EmbedBuilder builder = new EmbedBuilder();
                builder.setDescription("Du bist nicht in dem selben Sprachkanal");
                builder.setColor(Color.red);

                builder.setTimestamp(OffsetDateTime.now());
                channel.sendMessage(builder.build()).queue();
                return;
            }

            final GuildMusicManager musicManager = PlayerManager.getInstance().getMusicManager(channel.getGuild());
            final AudioPlayer audioPlayer = musicManager.audioPlayer;

            if(audioPlayer.getPlayingTrack() == null) {
                EmbedBuilder builder = new EmbedBuilder();
                builder.setDescription("Kein Lied vorhanden in der Queue.");
                builder.setColor(Color.red);

                builder.setTimestamp(OffsetDateTime.now());
                channel.sendMessage(builder.build()).queue();
                return;

            }

            musicManager.scheduler.nextTrack();
            EmbedBuilder builder = new EmbedBuilder();
            builder.setDescription("Nächstes Lied wird abgespielt.");
            builder.setColor(Color.red);

            builder.setTimestamp(OffsetDateTime.now());
            channel.sendMessage(builder.build()).queue();
        }
    }
}
