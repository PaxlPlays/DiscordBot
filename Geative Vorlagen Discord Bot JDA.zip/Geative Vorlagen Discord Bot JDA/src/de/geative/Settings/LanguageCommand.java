package de.geative.Settings;

import de.geative.Management.ServerCommand;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;

import java.awt.*;

public class LanguageCommand implements ServerCommand {
    @Override
    public void performCommand(Member m, TextChannel channel, Message message) {

        EmbedBuilder builder = new EmbedBuilder();
        builder.setTitle("language settings");
        builder.setDescription("Set the language for the bot, you can choose between: \n"
                + "\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67\uDB40\uDC7F English\n"
                + "\uD83C\uDDE9\uD83C\uDDEA Deutsch");
        builder.setColor(Color.CYAN);

        channel.sendMessage(builder.build()).queue(mess -> {
            mess.addReaction("\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67\uDB40\uDC7F").queue();
            mess.addReaction("\uD83C\uDDE9\uD83C\uDDEA").queue();
        });



    }
}
