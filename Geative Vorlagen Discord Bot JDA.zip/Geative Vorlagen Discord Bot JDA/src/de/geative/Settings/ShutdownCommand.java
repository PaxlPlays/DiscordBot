package de.geative.Settings;

import de.geative.Datenbank.LiteSQL;
import de.geative.Geative;
import de.geative.Management.ServerCommand;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;

import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ShutdownCommand implements ServerCommand {
    @Override
    public void performCommand(Member m, TextChannel channel, Message message) {

        if (m.hasPermission(Permission.ADMINISTRATOR)) {

            EmbedBuilder builder = new EmbedBuilder();
            builder.setTitle("Shutdown Bot");
            builder.setDescription("The bot has shutdown");
            builder.setColor(Color.GREEN);

            channel.sendMessage((CharSequence) builder.build()).queue();


            new Thread(() -> {

                String line = "";
                BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

                try {
                    while ((line = reader.readLine()) != null) {

                        if (Geative.INSTANCE.shardman != null) {
                            Geative.INSTANCE.shardman.setStatus(OnlineStatus.OFFLINE);
                            Geative.INSTANCE.shardman.shutdown();
                            LiteSQL.disconnect();
                            System.out.println("Bot offline");
                        }

                        if (Geative.INSTANCE.loop != null) {
                            Geative.INSTANCE.loop.interrupt();
                        }

                        reader.close();


                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }).start();


        } else {
            EmbedBuilder builder = new EmbedBuilder();
            builder.setTitle("Shutdown Bot");
            builder.setDescription("You have no rights to shutdown the bot");
            builder.setColor(Color.RED);

            channel.sendMessage(builder.build()).queue();
        }

    }
}

